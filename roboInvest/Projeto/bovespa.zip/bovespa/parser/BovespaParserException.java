package bovespa.parser;

public class BovespaParserException extends Exception {
    
    private static final long serialVersionUID = -5893292468923742843L;

    public BovespaParserException(Exception exc) {
        super(exc);
    }
}
